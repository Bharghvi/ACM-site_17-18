recentEventConfig=[
{
	"imgSrc":"img/acmSummerChallenge.jpg",
	"eventTitle":"ACM Summer Challenge",
	"date":"22/5/2017 to 5/7/2017",
	"time":"-",
	"venue":"online@",
	"contactPerson":["Deepanshu Sharma","Swapnil Patel"],
	"contactPersonPhone":["+917600828330","+918320933715"],
	"details":"This will be a 45 - 50 days long challenge on hackerearth with 25 - 30 problems.The initial problem will be of easy difficulty level and will inc along with later ques.The que will cover all topics upto basic STL library usage. Or it can be decide by prob setter.The target of the challenge is not to make them pro in competitive coding but to introduce them to how to approach a problem of real life.The performance of the executives in the challenge will determine their eligiblity for acm.This contest will be open to all 1st yearites who want to join ACM as executives."
},
{
	"imgSrc":"img/inception.jpg",
	"eventTitle":"Inception 2.0",
	"date":"20/8/2017",
	"time":"8:30pm to 10:30pm",
	"venue":"online@",
	"contactPerson":["Tanishka Khatri","Simran Bawkar"],
	"contactPersonPhone":["+919824259166","+917678024097"],
	"details":"Love to Code? Get a glimpse of the vast competitive coding world and know where you stand. We bring you Inception 2.0, a competitive coding contest meant exclusively for 1st and 2nd yearites. So make sure you have your HackerEarth accounts ready and Register in the link below. Let your skills, speed and accuracy decide your rank.Registration Link: <a href=\"https://goo.gl/QRM7FE\" target=\"_blank\">https://goo.gl/QRM7FE"
}
];

pastEventConfig1617=[
{
	"eventTitle":"CodeWars",
	"description":"An ICPC like coding competition. A team of three will code certain numbers of programming problems. It evaluates them on their coding skills as well as coordination."
},
{
	"eventTitle":"2 x 10 Relay",
	"description":"Team of two will code a given problem. One member of the team will get first ten minutes to code and another member will get ten minutes more to complete the code without communicating with former member."
},
{
	"eventTitle":"Tech IQ",
	"description":"A general technical current affairs quiz. Students can participate in team of two. There will be 2 rounds with first round being a written round."
},
{
	"eventTitle":"Epiphany",
	"description":"A 3 hour coding competition especially for first and second year students. Questions will be set so as to boost more enthusiasm for competitive coding in first year students."
},
{
	"eventTitle":"Designing Competition",
	"description":"A one hour long designing competition. The participants will be given the theme on spot. Without referring any material they need to design."
}
];

function listAllEvents(){
	parentHolder=document.getElementById("recentEvents");
	for(var i=0;i<recentEventConfig.length;i++)
	{
		var poster=createBreifEventBody(recentEventConfig[i],i);
		parentHolder.appendChild(poster);
	}
}

function createBreifEventBody(event, eventNumber){

	var div=document.createElement("div");
	div.setAttribute("class","vcol-4 vcol-md-6 vcol-sl-12");

	var childDiv=document.createElement("div");
	childDiv.setAttribute("class","eventsPoster");
	childDiv.setAttribute("onclick","showDetailEvent("+eventNumber+")");

	var grandChildImg=document.createElement("img");
	grandChildImg.setAttribute("src",event["imgSrc"]);
	grandChildImg.setAttribute("class","eventPics");

	var grandChildH4=document.createElement("h4");
	grandChildH4.setAttribute("class","eventTitle");
	grandChildH4.innerHTML=event["eventTitle"];

	childDiv.appendChild(grandChildImg);
	childDiv.appendChild(grandChildH4);

	div.appendChild(childDiv);
	return div;

}

function listAllPastEvents(){
	var parentHolder=document.getElementById('pastEvents1617');
	for(var i=0;i<pastEventConfig1617.length;i++)
	{
		var poster=bodyForPastEvents(pastEventConfig1617[i]);
		parentHolder.appendChild(poster);
	}
}

function bodyForPastEvents(event){
	var div=document.createElement("div");
	div.setAttribute("class","vcol-12 vcol-sl-12 vcol-md-12");

	var childDiv=document.createElement("div");
	childDiv.setAttribute("class","pastEventDiv");

	var grandChildH3=document.createElement('h3');
	grandChildH3.innerHTML=event["eventTitle"];

	var grandChildP=document.createElement('p');
	grandChildP.innerHTML=event["description"];

	childDiv.appendChild(grandChildH3);
	childDiv.appendChild(grandChildP);

	div.appendChild(childDiv);
	return div;

}

listAllEvents();
listAllPastEvents();